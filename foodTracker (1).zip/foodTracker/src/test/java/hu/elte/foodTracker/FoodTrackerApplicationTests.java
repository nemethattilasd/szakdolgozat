package hu.elte.foodTracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
